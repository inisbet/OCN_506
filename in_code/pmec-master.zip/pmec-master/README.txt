This is code for the 2020 Effective Computing class.

==========================================================

* first_script.sh is an example of a bash shellscript.  One thing is does is create the pmec_output directory.

==========================================================

* shared is a directory for python modules that I write, such as my_module.py

==========================================================

